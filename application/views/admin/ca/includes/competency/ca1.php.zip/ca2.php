<table border="1"  class="table table-hover table-striped">
	<thead>
		<tr>
			<th  rowspan="2" > <center>SKILLS</center></th>
			<th  rowspan="2"><center>COMPETENT</center></th>
			<th  rowspan="2">COMMENTS</th>
			<th  rowspan="2">DATE & INITIAL</th>
		</tr>
	</thead>

	<tbody>
		<tr>
			<td>Foley insertion–male/female</td>
			<td> 
			  <select name="row001" ng-model="p.row001" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row002" ng-model="p.row002" value="" class="form-control"></td>
		   <td><input type="text" name="row003" ng-model="p.row003" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Enternal Feedings:</td>
			<td> 
			  <select name="row011" ng-model="p.row011" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row012" ng-model="p.row012" value="" class="form-control"></td>
		   <td><input type="text" name="row013" ng-model="p.row013" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Bolus</td>
			<td> 
			  <select name="row021" ng-model="p.row021" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row022" ng-model="p.row022" value="" class="form-control"></td>
		   <td><input type="text" name="row023" ng-model="p.row023" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Continuous</td>
			<td> 
			  <select name="row031" ng-model="p.row031" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row032" ng-model="p.row032" value="" class="form-control"></td>
		   <td><input type="text" name="row033" ng-model="p.row033" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Removal/insertion PEG tubes</td>
			<td> 
			  <select name="row041" ng-model="p.row041" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row042" ng-model="p.row042" value="" class="form-control"></td>
		   <td><input type="text" name="row043" ng-model="p.row043" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Equipment:</td>
			<td> 
			  <select name="row051" ng-model="p.row051" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row052" ng-model="p.row052" value="" class="form-control"></td>
		   <td><input type="text" name="row053" ng-model="p.row053" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>IV pumps</td>
			<td> 
			  <select name="row061" ng-model="p.row061" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row062" ng-model="p.row062" value="" class="form-control"></td>
		   <td><input type="text" name="row063" ng-model="p.row063" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Enternal pumps</td>
			<td> 
			  <select name="row071" ng-model="p.row071" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row072" ng-model="p.row072" value="" class="form-control"></td>
		   <td><input type="text" name="row073" ng-model="p.row073" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Oxygen concentrator</td>
			<td> 
			  <select name="row081" ng-model="p.row081" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row082" ng-model="p.row082" value="" class="form-control"></td>
		   <td><input type="text" name="row083" ng-model="p.row083" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Oxygen tank</td>
			<td> 
			  <select name="row091" ng-model="p.row091" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row092" ng-model="p.row092" value="" class="form-control"></td>
		   <td><input type="text" name="row093" ng-model="p.row093" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Nebulizer</td>
			<td> 
			  <select name="row101" ng-model="p.row101" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row102" ng-model="p.row102" value="" class="form-control"></td>
		   <td><input type="text" name="row103" ng-model="p.row103" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>IV therapy:</td>
			<td> 
			  <select name="row111" ng-model="p.row111" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row112" ng-model="p.row112" value="" class="form-control"></td>
		   <td><input type="text" name="row113" ng-model="p.row113" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Peripheral/INT</td>
			<td> 
			  <select name="row121" ng-model="p.row121" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row122" ng-model="p.row122" value="" class="form-control"></td>
		   <td><input type="text" name="row123" ng-model="p.row123" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Hydration/medications</td>
			<td> 
			  <select name="row131" ng-model="p.row131" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row132" ng-model="p.row132" value="" class="form-control"></td>
		   <td><input type="text" name="row133" ng-model="p.row133" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Dressing change</td>
			<td> 
			  <select name="row141" ng-model="p.row141" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row142" ng-model="p.row142" value="" class="form-control"></td>
		   <td><input type="text" name="row143" ng-model="p.row143" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Central line maintenance</td>
			<td> 
			  <select name="row151" ng-model="p.row151" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row152" ng-model="p.row152" value="" class="form-control"></td>
		   <td><input type="text" name="row153" ng-model="p.row153" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Irrigations:</td>
			<td> 
			  <select name="row161" ng-model="p.row161" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row162" ng-model="p.row162" value="" class="form-control"></td>
		   <td><input type="text" name="row163" ng-model="p.row163" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Bladder</td>
			<td> 
			  <select name="row171" ng-model="p.row171" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row172" ng-model="p.row172" value="" class="form-control"></td>
		   <td><input type="text" name="row173" ng-model="p.row173" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Colostomy</td>
			<td> 
			  <select name="row181" ng-model="p.row181" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row182" ng-model="p.row182" value="" class="form-control"></td>
		   <td><input type="text" name="row183" ng-model="p.row183" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Venipunctures</td>
			<td> 
			  <select name="row191" ng-model="p.row191" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row192" ng-model="p.row192" value="" class="form-control"></td>
		   <td><input type="text" name="row193" ng-model="p.row193" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Transporting lab specimens</td>
			<td> 
			  <select name="row201" ng-model="p.row201" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row202" ng-model="p.row202" value="" class="form-control"></td>
		   <td><input type="text" name="row203" ng-model="p.row203" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Suctioning</td>
			<td> 
			  <select name="row211" ng-model="p.row211" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row212" ng-model="p.row212" value="" class="form-control"></td>
		   <td><input type="text" name="row213" ng-model="p.row213" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Tracheostomy care</td>
			<td> 
			  <select name="row221" ng-model="p.row221" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row222" ng-model="p.row222" value="" class="form-control"></td>
		   <td><input type="text" name="row223" ng-model="p.row223" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Wound care</td>
			<td> 
			  <select name="row231" ng-model="p.row231" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row232" ng-model="p.row232" value="" class="form-control"></td>
		   <td><input type="text" name="row233" ng-model="p.row233" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>IDG care planning</td>
			<td> 
			  <select name="row241" ng-model="p.row241" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row242" ng-model="p.row242" value="" class="form-control"></td>
		   <td><input type="text" name="row243" ng-model="p.row243" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Assessment skills</td>
			<td> 
			  <select name="row251" ng-model="p.row251" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row252" ng-model="p.row252" value="" class="form-control"></td>
		   <td><input type="text" name="row253" ng-model="p.row253" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Reassessment skills</td>
			<td> 
			  <select name="row261" ng-model="p.row261" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row262" ng-model="p.row262" value="" class="form-control"></td>
		   <td><input type="text" name="row263" ng-model="p.row263" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Spiritual assessment</td>
			<td> 
			  <select name="row271" ng-model="p.row271" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row272" ng-model="p.row272" value="" class="form-control"></td>
		   <td><input type="text" name="row273" ng-model="p.row273" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Psychosocial assessment skills</td>
			<td> 
			  <select name="row281" ng-model="p.row281" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row282" ng-model="p.row282" value="" class="form-control"></td>
		   <td><input type="text" name="row283" ng-model="p.row283" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Effectively manages pain</td>
			<td> 
			  <select name="row291" ng-model="p.row291" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row292" ng-model="p.row292" value="" class="form-control"></td>
		   <td><input type="text" name="row293" ng-model="p.row293" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Care and comfort measures</td>
			<td> 
			  <select name="row301" ng-model="p.row301" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row302" ng-model="p.row302" value="" class="form-control"></td>
		   <td><input type="text" name="row303" ng-model="p.row303" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Dietary counseling</td>
			<td> 
			  <select name="row311" ng-model="p.row311" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row312" ng-model="p.row312" value="" class="form-control"></td>
		   <td><input type="text" name="row313" ng-model="p.row313" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Role in bereavement</td>
			<td> 
			  <select name="row321" ng-model="p.row321" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row322" ng-model="p.row322" value="" class="form-control"></td>
		   <td><input type="text" name="row323" ng-model="p.row323" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>Standard Precautions</td>
			<td> 
			  <select name="row331" ng-model="p.row331" class="form-control col-sm-5" >
				<option value="" >Select Choice...</option>
				<option value="yes" >yes</option>
				<option value="no" >no</option>        
			  </select>
		   </td>
		   <td><input type="text" name="row332" ng-model="p.row332" value="" class="form-control"></td>
		   <td><input type="text" name="row333" ng-model="p.row333" value="" class="form-control"></td>
		</tr>
		
	</tbody>
</table>

<br />
<div class="row">
	<div class="col-sm-6">
		<div class="">
			<label class="control-label" >Comments: </label>
			<div class="input-group">
			<textarea name="comments" ng-model="p.comments"></textarea>
			</div>
		</div>
	</div>
</div>
<br />

 <div class="row">
                   <div class="col-sm-6">
  <?php if(empty($user_esign)){ ?>  <p>--------------------------------------------</p> <?php }else{ ?>  <img src="<?php echo $user_esign;?>"> <?php } ?>	
			    <p>Employee Signature</p>
		   </div>
                   <div class="col-sm-6">
						<div class="">
							<label class="control-label" >Date: <span class="required"> *</span></label>
							<div class="input-group">
							<input type="text" name="date_of_employeesign" ng-model="p.date_of_employeesign" value="" class="form-control datepicker" data-date-format="mm/dd/yyyy">
								<div class="input-group-addon">
									<a href="#"><i class="entypo-calendar"></i></a>
								</div>
							</div>
						</div>
					</div>
              </div>

           <div class="row">
                   <div class="col-sm-6">
  <?php if(empty($admin_info->esignature)){ ?>  <p>--------------------------------------------</p> <?php }else{ ?>  <img src="<?php echo $admin_info->esignature;?>"> <?php } ?>	
			    <p>Supervisor Signature</p>
		   </div>
                   <div class="col-sm-6">
						<div class="">
							<label class="control-label" >Date: <span class="required"> *</span></label>
							<div class="input-group">
							<input type="text" name="date_of_supervisorsign" ng-model="p.date_of_supervisorsign" value="" class="form-control datepicker" data-date-format="mm/dd/yyyy">
								<div class="input-group-addon">
									<a href="#"><i class="entypo-calendar"></i></a>
								</div>
							</div>
						</div>
					</div>
              </div>
