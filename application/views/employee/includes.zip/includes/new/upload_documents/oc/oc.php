<table>
	<thead>
		<tr>
			<th>CHECKLIST</th>
			<th>DATE COMPLETED</th>
			<th>ORIENTATION BY WHOM</th>
			<th>PERSONNEL INITIALS</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td> 1.	Tour of office/introduction of organization personnel</td>
			<td><input type="date" name="row001" ng-model="p.row001" value="" class="form-control"></td>
			<td><input type="text" name="row002" ng-model="p.row002" value="" class="form-control"></td>
			<td><input type="text" name="row003" ng-model="p.row003" value="" class="form-control"></td>
		</tr>
		<tr>
			<td> 2.  	Introduction to work stations</td>
			<td><input type="date" name="row001" ng-model="p.row001" value="" class="form-control"></td>
			<td><input type="text" name="row002" ng-model="p.row002" value="" class="form-control"></td>
			<td><input type="text" name="row003" ng-model="p.row003" value="" class="form-control"></td>
		</tr>
		<tr>
			<td> 3.	Completion of all employment forms</td>
			<td><input type="date" name="row001" ng-model="p.row001" value="" class="form-control"></td>
			<td><input type="text" name="row002" ng-model="p.row002" value="" class="form-control"></td>
			<td><input type="text" name="row003" ng-model="p.row003" value="" class="form-control"></td>
		</tr>
		<tr>
			<td>
				4.	Personnel file
				<ol type="A">
					<li>Application</li>
					<li>Sign job description (copy to personnel)</li>
					<li>Professional license, certification, registration, as appropriate</li>
					<li>Driver's license, as appropriate</li>
					<li>Proof of auto insurance, as appropriate</li>
					<li>Physical exam and drug test, as appropriate</li>
					<li>Standard precautions orientation</li>
					<li>Criminal background check</li>
				</ol>
			</td>
			<td><input type="date" name="row001" ng-model="p.row001" value="" class="form-control"></td>
			<td><input type="text" name="row002" ng-model="p.row002" value="" class="form-control"></td>
			<td><input type="text" name="row003" ng-model="p.row003" value="" class="form-control"></td>
		</tr>
	</tbody>
</table>
	