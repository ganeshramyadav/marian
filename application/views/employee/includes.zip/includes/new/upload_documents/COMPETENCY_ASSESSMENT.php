<div class="container" style="margin-left: 8%;">
	<form method="post" action="#">
		<div class="section-header row">
			<h1>ANNUAL COMPETENCY ASSESSMENT SKILLS CHECKLIST REGISTERED NURSE</h1>		
		</div>
		<hr class="heavy"/>
		<br />
		
		<div class="container">
			<div class="row">
				<label style="float:left;">Name:</label><input class="form-control" style="display: inline; width:inherit;"/>
			</div>
			<p></p>
			<div class="row">
				<label style="float:left;">Date of Employment:</label><input class="form-control" type="date" style="display: inline; width:inherit;"/>
			</div>
			<p></p>
			<div class="row">
				<label style="float:left;">Date Completed:</label><input class="form-control" type="date" style="display: inline; width:inherit;"/>
			</div>
			<br />
			<div class="row">
				<p style="text-align: center;">Verbal Test=<span style="font-weight: bold;">V *</span>Written Test=<span style="font-weight: bold;">W*</span>Observation=<span style="font-weight: bold;">O*</span>Demonstration=<span style="font-weight: bold;">D*</span>Special Training=<span style="font-weight: bold;">ST</span></p>
			</div>
			<div class="row">
				<?php 
					// echo $rn_info->discipline_id;
					// echo $id;
					// echo "<pre>"; print_r($data); echo "</pre>";
					// echo $ca_info->discipline_id;
					
					// $this->load->view('admin/includes/new/upload_documents/competency/ca'.$disciplineid.'.php'); 
				?>
			</div>
		</div>
	</form>
</div>